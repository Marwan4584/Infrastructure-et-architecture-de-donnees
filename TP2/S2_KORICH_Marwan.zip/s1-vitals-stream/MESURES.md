# MESURES — Séance 1

## Versions
| Outil | Version |
|---|---|
| Docker Engine | 29.4.3 |
| Docker Compose | v5.1.4 |
| Python | 3.11.5 |

## Partie 1

**Q1.1** — Non, c2 ne voit pas le fichier. Chaque conteneur possède sa propre couche inscriptible au-dessus des couches en lecture seule de l'image : ce qu'écrit c1 reste dans sa couche et disparaît avec lui.

### Mesure 1
| Grandeur | Valeur |
|---|---|
| Taille python:3.12-slim | 145 MB |
| Taille image finale (vitals-producer:0.1) | 193 MB |
| Couches non vides (docker history) | 8 (4 de l'image de base + 4 du Dockerfile) |
| Couche la plus volumineuse | Couche de base Debian : 101 MB ; parmi les nôtres : RUN pip install, 48,9 MB |

### Mesure 2
| Scénario de rebuild | Durée / étapes CACHED |
|---|---|
| Aucune modification | 0.65 s / 5 CACHED (toutes les étapes du Dockerfile) |
| Modification de producer.py | 0,37 s / 3 CACHED (WORKDIR, COPY requirements, pip install) |
| Modification de requirements.txt | 2,67 s / 1 CACHED (WORKDIR) — pip install refait (2,2 s) |

**Q1.2** — Avec un unique `COPY . ./` placé avant le `RUN pip install`, c'est le scénario « modification de producer.py » qui changerait : toute modification du code invaliderait la couche COPY, donc aussi le pip install et toutes les couches suivantes. Sa durée passerait d'environ 0,4 s à environ 2,7 s, comme le scénario requirements.txt, alors que les deux autres scénarios resteraient inchangés.

## Partie 3

### Décisions
| Décision | Valeur retenue |
|---|---|
| Port hôte publié en face de 29092 | `29092` (même numéro des deux côtés, plus lisible) |
| KAFKA_PROCESS_ROLES | `broker,controller` (un seul nœud porte les deux rôles en KRaft) |
| Facteur de réplication des topics internes | `1` (un seul broker, impossible d'avoir plus de copies) |
| KAFKA_AUTO_CREATE_TOPICS_ENABLE | `false` (une faute de frappe sur un nom de topic provoque une erreur au lieu de créer un topic fantôme) |
| Volume nommé des journaux Kafka | `kafka-data` (nom réel : `s1-vitals-stream_kafka-data`) |

### Mesure 4
Temps entre `docker compose up -d kafka` et l'état healthy : **8,1 s** (image déjà téléchargée).

### Topic
`mimic-vitals` créé avec **3 partitions** et un **facteur de réplication de 1**. Trois partitions permettent d'observer la répartition par clé. Le nombre sera augmenté en séance 2.

**Q3.1** — `--replication-factor` ne peut pas valoir 2 parce qu'il n'y a qu'**un seul broker**. Une réplique doit être placée sur un broker différent du leader, et deux copies d'une partition ne peuvent pas être hébergées par le même broker. Kafka refuse la création avec l'erreur `INVALID_REPLICATION_FACTOR` (InvalidReplicationFactorException) : *Unable to replicate the partition 2 time(s): The target replication factor of 2 cannot be reached because only 1 broker(s) are registered.* (message observé dans les logs du broker, QuorumController).

### Mesure 5
| Clé | Partition(s) et offsets observés |
|---|---|
| P001 | partition 2 — offsets 0, 1, 2 |
| P002 | partition 1 — offset 0 |
| P003 | partition 0 — offset 0 |

Offsets de fin (prochain offset à écrire) : partition 0 → 1, partition 1 → 1, partition 2 → 3. Total : 5 messages.

**Q3.2** — Oui, les trois messages de P001 sont tous dans la même partition (2), car le partitionneur calcule la partition à partir du hachage de la clé, et une même clé donne toujours la même partition. Leurs offsets se suivent (0, 1, 2), dans l'ordre exact d'envoi (HR, puis SPO2, puis ABP_SYS). L'ordre est donc garanti pour un même patient, puisqu'il est garanti à l'intérieur d'une partition, mais il ne l'est pas entre patients de partitions différentes : à la lecture, P002 (partition 1) peut apparaître avant ou après P001 alors qu'il a été envoyé entre deux messages de P001.

> Remarque : dans l'image `cp-kafka:7.8.0` (Kafka 3.8), la classe `kafka.tools.GetOffsetShell` de l'énoncé n'existe plus (`ClassNotFoundException`). L'outil a été déplacé et s'appelle maintenant `kafka-get-offsets` ; c'est ce script qui a été utilisé pour relever les offsets de fin.

## Partie 4

### Décisions de configuration du producteur
| Paramètre | Valeur | Justification |
|---|---|---|
| acks | `all` | le leader et toutes les répliques ISR confirment : durabilité maximale, obligatoire avec l'idempotence |
| linger.ms | `5` | petit regroupement en lots, latence négligeable pour un flux à ~1 Hz par patient |
| retries | `5` | imposé |
| enable.idempotence | `True` | un retry ne crée ni doublon ni inversion d'ordre |
| partitioner | `murmur2_random` | même hachage murmur2 que le client Java (Flink) ; le défaut librdkafka (`consistent_random`, CRC32) n'est pas interopérable |
| NB_PATIENTS | `12` | 12 lits |
| INTERVAL_S | `1.0` | un moniteur ICU échantillonne à ~1 Hz |

Clé Kafka = `patient_id` (UTF-8) : tous les relevés d'un patient vont dans la même partition, sa série reste ordonnée.

## Partie 5

### Mesure 7
| Grandeur | Valeur |
|---|---|
| Somme des offsets de fin avant (t0) | 113 |
| Somme des offsets de fin après 60 s (t1) | 113 |
| Débit calculé (t1 - t0) / 60 | 0.0 msg/s |
| Débit annoncé par le producteur à l'arrêt |  msg/s |
| INTERVAL_S / NB_PATIENTS | 1.0 / 12 (théorique : 12 msg/s, écart 100.0 %) |

| Grandeur | Valeur |
|---|---|
| Débit mesuré avec INTERVAL_S=0.1 | 117.6 msg/s |
| Écart avec la valeur théorique (120 msg/s) | 2.0 % |

**Q5.1** — Le débit théorique est NB_PATIENTS / INTERVAL_S. Le débit réel est légèrement inférieur, car la période d'un tour de boucle n'est pas exactement INTERVAL_S : c'est INTERVAL_S + le temps de travail du tour (12 appels à produce, sérialisation JSON, poll), puisque le sleep est ajouté après ce travail au lieu de le compenser. Avec INTERVAL_S = 1 s, ce surcoût de quelques millisecondes est négligeable (écart < 5 %). Avec INTERVAL_S = 0.1 s, il pèse relativement 10 fois plus, et la précision de time.sleep (granularité de l'ordonnanceur, quelques ms) s'y ajoute : l'écart devient plus visible. Pour tenir un débit exact, il faudrait dormir jusqu'à une échéance absolue (début + n × INTERVAL_S) plutôt qu'une durée fixe.

### Mesure 8
| Observation | Valeur relevée |
|---|---|
| Le processus producteur s'arrête-t-il ? | Non, il continue de tourner |
| Message d'erreur exact (première ligne) |  |
| Délai entre stop et la première erreur | 69.2 s |
| Après start, la production reprend-elle sans relancer le script ? | Non |
| Des messages produits pendant la coupure ont-ils été perdus ? | Non, 0 échec de livraison |

**Q5.2** — Entre `stop` et `start`, le producteur ne s'arrête pas : `produce()` continue de déposer les relevés dans le buffer local de librdkafka, et les e*vois qui échouent faute de broker restent en file d'attente au lieu d'être abandonnés. Avec `acks=all`, un message n'est considéré comme livré qu'après l'accusé du leader et des répliques ISR, donc aucun relevé non confirmé n'est retiré du buffer ; `retries=5` autorise la réémission des lots dont l'envoi a échoué en cours de route. `enable.idempotence=True` associe à chaque message un identifiant de producteur et un numéro de séquence : au retour du broker, les réémissions ne créent ni doublon ni inversion d'ordre dans une partition. La durée pendant laquelle le producteur peut tenir sans broker est bornée par `message.timeout.ms` (`delivery.timeout.ms`, 300 s par défaut), au-delà duquel les messages en attente sont déclarés en échec via le callback, et par la capacité du buffer local (`queue.buffering.max.messages` / `max.kbytes`), qui, une fois pleine, fait lever `BufferError` à `produce()`.

